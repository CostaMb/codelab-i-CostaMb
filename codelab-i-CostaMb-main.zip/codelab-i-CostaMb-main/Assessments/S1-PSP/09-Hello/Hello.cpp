#include <iostream>
using namespace std;

void hello(){
  cout << "Hello" << endl;
}

int main(){

  hello();

  return 0;
}
