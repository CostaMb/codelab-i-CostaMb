#include <iostream>
using namespace std;

int main() {
    int num1 = 8;        // first integer
    int num2 = 10;       // second integer
    int sum = num1 + num2;  // add them together

    cout << sum << endl;   // print the sum

    return 0;
}
