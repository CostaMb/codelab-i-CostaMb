#include <iostream>
#include <string>
using namespace std;

int main() {
    cout << "Coding is Cool" << endl;
    return 0;
}
